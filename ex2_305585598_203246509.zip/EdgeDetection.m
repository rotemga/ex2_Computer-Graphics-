M = double(imread('lena.bmp'));
[n,m] = size(M);
Dx = zeros(n-2,m-2);
Dy = zeros(n-2,m-2);


for i=2:n-1
    for j=2:n-1
        Dx(i,j) = (2*M(i-1,j-1) - 2*M(i-1,j+1) + M(i,j-1) -M(i,j+1) + 2*M(i+1, j-1) - 2*M(i+1,j+1));
        Dy(i,j) = (2*M(i-1,j-1) - 2*M(i+1, j-1) + M(i-1,j) - M(i+1,j) + 2*M(i-1,j+1) - 2*M(i+1,j+1));

    end
end


for i=1:n-1
    for j=1:n-1
        G(i,j) = (Dx(i,j)^2 + Dy(i,j)^2)^0.5;
    end
end

G = G/max(G(:));
imshow(G);
        
        