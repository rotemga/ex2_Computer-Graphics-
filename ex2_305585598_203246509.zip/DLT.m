function[H] = DLT(matches)
[m,n] = size(matches);
%m is the number of matches. n=4 (number of col)

homogenMatrix = ones(6,m);
%convert to homogeneous coordinates.
for i=1:m
	homogenMatrix(1:2,i) = matches(i,1:2);
    homogenMatrix(4:5,i) = matches(i,3:4);
end
matches = homogenMatrix;





%normalize points xi
T_transalte_matrix_xi = Ttranslate(matches(1:3,:));
T_scale_matrix_xi = Tscale(T_transalte_matrix_xi*matches(1:3,:));
T = T_scale_matrix_xi*T_transalte_matrix_xi;


%normalize points xiTag
T_transalte_matrix_xi_tag = Ttranslate(matches(4:6,:));
T_scale_matrix_xi_tag = Tscale(T_transalte_matrix_xi_tag*matches(4:6,:));
T_tag = T_scale_matrix_xi_tag* T_transalte_matrix_xi_tag;


A = zeros(2*m,9);
for i=1:m
    xi = T*matches(1:3,i);
    xi_tag = T_tag*matches(4:6,i);
    A(2*i-1,:) = [0 0 0 -xi_tag(3)*xi' xi_tag(2)*xi'];
    A(2*i, :) = [xi_tag(3)*xi' 0 0 0 -xi_tag(1)*xi'];
end

[U,S,V] = svd(A);

h = V(:,size(V,2));%the last vector is the vector that suits to the smallest singular value
%Determine the homograpghy H from h and Denormalize the solusion
H = inv(T_tag) * horzcat(h(1:3),h(4:6),h(7:9)) * T;
H = H/H(3,3);



end

function [T_transalte_matrix] = Ttranslate(points)
Mean = mean(points,2);
T_transalte_matrix = [1 0 -Mean(1)
                        0 1 -Mean(2)
                        0 0 1];
end




function [T_scale_matrix] = Tscale(points)
n = size(points,2);
sum_norm = 0;
for i=1:n
    sum_norm = sum_norm + norm(points((1:2),i));
end
scalar = (n*sqrt(2))/sum_norm;

T_scale_matrix = [scalar 0 0
                        0 scalar 0
                        0 0 1];

end