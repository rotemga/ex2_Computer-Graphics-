function [error] = ComputeError(pnts_gt,pnts_computed)
    diff=pnts_gt(1:2,:)-pnts_computed(1:2,:);
    distances_squared=sqrt(sum(diff.^2,1)).^2;
    error=sum(distances_squared);
end
