H=[1 .2 0; .1 1 0; 0.5 0.2 1];
ExmplesCommon('Tiger.bmp',H,0.3);



