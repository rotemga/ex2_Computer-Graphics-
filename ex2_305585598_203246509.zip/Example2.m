H=[1 .7 0; .1 0.5 0; 0.5 0.4 1];
ExmplesCommon('left.pgm',H,0.8);