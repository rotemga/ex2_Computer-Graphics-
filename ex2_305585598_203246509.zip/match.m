% num = match(image1, image2)
%
% This function reads two images, finds their SIFT features, and
%   displays lines connecting the matched keypoints.  A match is accepted
%   only if its distance is less than distRatio times the distance to the
%   second closest match.
% It returns the number of matches displayed.
%
% Example: match('scene.pgm','book.pgm');

function [num_matches,matches,dist_vals] = match(image1, image2,distRatio)

% Find SIFT keypoints for each image
[~, des1, loc1] = sift(image1);
[~, des2, loc2] = sift(image2);

matches=[];
% For each descriptor in the first image, select its match to second image.
des2t = des2';                          % Precompute matrix transpose
num_matches=0;
for i = 1 : size(des1,1)
   dotprods = des1(i,:) * des2t;        % Computes vector of dot products
   [vals,indx] = sort(acos(dotprods));  % Take inverse cosine and sort results
   
   % Check if nearest neighbor has angle less than distRatio times 2nd.
   if (vals(1) < distRatio * vals(2))
      num_matches=num_matches+1;
      dist_vals(num_matches)=vals(1)/vals(2);
      matches = [matches; loc1(i, 1:2),loc2(indx(1), 1:2)];
      
   end
end





