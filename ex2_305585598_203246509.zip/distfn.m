function [ inliers, M ] = distfn( M, x, t )

inliers = [];

n = size(x, 1);

one_aug = [x( :,1:2) ones(n, 1) x( :,3:4)  ones(n, 1)];
    
for i=1:n
    a = M * one_aug( i,1:3)';
    b = one_aug(i,4:6);

    dist = norm( a / a(3) - b' );
    if (dist < t)
        inliers = [inliers i];
    end
    
end

end

