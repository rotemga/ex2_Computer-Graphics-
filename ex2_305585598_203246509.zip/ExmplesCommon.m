function ExmplesCommon(imageName,H,dist_ratio)
    OriginalIm=imread(imageName);
    ProjectedIm=ComputeProjective(imageName,H);
    
    [~, matches, ~] = match(OriginalIm, ProjectedIm, dist_ratio);
    
    
    H_dlt = DLT( matches );
    [pnts_gt,pnts_computed] = ComputeTestPoints(H,H_dlt);
    error = ComputeError(pnts_gt, pnts_computed);

    H_RANSAC = RANSAC_Wrapper(matches, @DLT, @distfn, @degenfn, 4, 1400, 0, 1000, 1000);
    fprintf('error for DLT: %d\n',error);
    fprintf('error for ransac: %d\n',ComputeError(H, H_RANSAC));

end