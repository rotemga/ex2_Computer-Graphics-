function[TranformedIm] = ComputeProjective(Im, H)
h_proj = projective2d(H);
TranformedIm = imwarp(Im,h_proj);

end