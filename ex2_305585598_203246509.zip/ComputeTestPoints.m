function [pnts_gt,pnts_computed] =ComputeTestPoints(H_gt,H_computed)
    num_points=100;
    points = randn(2, num_points);
    norms = sqrt(sum(points.^2,1));    %precompute norms
    for i = 1 : num_points
        points(:,i)=points(:,i)/norms(i);
    end
    points=[points;ones(1, num_points)];
    
    pnts_gt = H_gt * points;
    pnts_computed = H_computed * points;
end
