function [ r ] = degenfn( x )
    r=0;
end